/*
Minimalistic Form. 
by: Matheus Marsiglio
matmarsiglio@gmail.com
*/